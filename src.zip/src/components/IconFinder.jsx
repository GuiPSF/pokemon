
const icons = import.meta.glob('./src/assets/icons/*.png', { eager: true });
console.log(Object.keys(icons)); // deve mostrar todos os caminhos encontrados

export function getIconByName(name) {
  for (const path in icons) {
    if (path.includes(name)) {
      return icons[path].default;
    }
  }
  return null;
}
